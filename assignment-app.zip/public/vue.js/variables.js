const variables={
    API_URL:"http://localhost/vue-js-laravel/assignment-app/public/",
}