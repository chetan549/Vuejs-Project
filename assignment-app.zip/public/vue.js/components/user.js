const user={
    template:'#user-template',

    data(){
        return{
        	users:[],
            modalTitle:"",
            UserId:'',
            UserName:"",
            UserEmail:"",
            IsAuthor:"",
            UserPhone: "",
            UserCountry: "",
            UserStatus: {status:1},
            UserCreatedAt: "",
            authoryes: "1",
            authorno: "0",
            options: [{id:'1',name:'Active'},{id:'0',name:'Disable'}]
        }
    },
    methods:{
        refreshData(){
            axios.get(variables.API_URL+"list-users")
            .then((response)=>{
                this.users=response.data;
            });
        },
        closeModal(){
        	document.getElementById('close').click();
        },
        addClick(){
            this.modalTitle="Add User";
            this.UserId='';
            this.UserName="";
            this.UserEmail="",
            this.IsAuthor="",
            this.UserPhone="",
            this.UserCountry="",
            //this.UserStatus="",
            this.UserCreatedAt=""
        },
        editClick(user){
            this.modalTitle="Edit User";
            this.UserId=user.id;
            this.UserName=user.user_name;
            this.UserEmail=user.user_email,
            this.IsAuthor=user.is_author,
            this.UserPhone=user.user_phone,
            this.UserCountry=user.user_country,
            this.UserStatus={status:user.user_status},
            this.UserCreatedAt=user.created_at
        },
        createClick(){
        	console.log(this.UserStatus.status)
            axios.post(variables.API_URL+"users",{
                user_name: this.UserName,
                user_email: this.UserEmail,
                is_author: this.IsAuthor,
                user_phone: this.UserPhone,
                user_country: this.UserCountry,
                user_status: this.UserStatus.status,
            })
            .then((response)=>{
                this.refreshData();
                alert(response.data.msg);
                this.closeModal();
            });
        },
        updateClick(id){
            axios.put(variables.API_URL+"users/"+id,{
                user_name: this.UserName,
                user_email: this.UserEmail,
                is_author: this.IsAuthor,
                user_phone: this.UserPhone,
                user_country: this.UserCountry,
                user_status: this.UserStatus.status,
            })
            .then((response)=>{
                this.refreshData();
                alert(response.data.msg);
                this.closeModal();
            });
        },
        deleteClick(id){
            if(!confirm("Are you sure?")){
                return;
            }
            axios.delete(variables.API_URL+"users/"+id)
            .then((response)=>{
                this.refreshData();
                alert(response.data.msg);
            });

        }

    },
    mounted:function(){
        this.refreshData();
        this.closeModal();
    }

}
