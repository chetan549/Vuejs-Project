const routes=[
    {path:'/',component:user},
]

const router=new VueRouter({
    routes
})

const app = new Vue({
    router
}).$mount('#app')