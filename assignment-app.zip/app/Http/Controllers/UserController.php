<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;

class UserController extends Controller
{


    /**
     * Show the details for a given user.
     *
     * @param  int  $id
     * @return \Illuminate\View\View
     */
    public function show($id)
    {

    }


    /**
     * List the Users    
     */

    public function index(){

        return view('pages.users');

    }

    /**
     * List Users Api
     * @param 
     * @return json
     */

    public function listUsers(){

        $users = User::all();

        return response()->json($users);

    }


    public function store(Request $request){

        //dd($request);

        $user = new User;
        $user->user_name = $request->user_name;
        $user->user_email = $request->user_email;
        $user->is_author = $request->is_author;
        $user->user_phone = $request->user_phone;
        $user->user_country = $request->user_country;
        $user->user_status = $request->user_status;

        if ($user->save()) {
            return response()->json(['msg' => 'User Added Successfully.']);
        }else{
            return response()->json(['msg' => 'Unable to Add User.']);
        }

    }

    public function update($id,Request $request){

        //dd($request->user_status);

        $user = User::find($id);
        $user->user_name = $request->user_name;
        $user->user_email = $request->user_email;
        $user->is_author = $request->is_author;
        $user->user_phone = $request->user_phone;
        $user->user_country = $request->user_country;
        $user->user_status = $request->user_status;

        if ($user->save()) {
            return response()->json(['msg' => 'User Updated Successfully.']);
        }else{
            return response()->json(['msg' => 'Unable to Update User.']);
        }

    }

    public function destroy($id){

        if(User::where('id',$id)->delete()){
         return response()->json(['msg' => 'User Deleted Successfully.']);
     }else{
        return response()->json(['msg' => 'Unable to Delete User.']);
    }

}



}