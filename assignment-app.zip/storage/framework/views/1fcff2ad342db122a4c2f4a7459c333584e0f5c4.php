<!DOCTYPE html>
<html lang="en">
<head>

	<title>Vue.Js Assignment</title>

	<!-- meta info -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- meta info -->

	<!-- bootstrap style -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
	<!-- bootstrap style -->


</head>

<body>

	<?php echo $__env->yieldContent('content'); ?>
	
	<!-- vue.js global variables -->
	<script src="<?php echo e(url('/')); ?>/vue.js/variables.js"></script>
	<!-- vue.js global variables -->

	<!-- axios -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.21.1/axios.min.js"></script>
	<!-- axios -->

	<!-- main vue.js -->
	<script src="https://unpkg.com/vue/dist/vue.js"></script>
	<!-- main vue.js -->

	<!-- router vue.js -->
	<script src="https://unpkg.com/vue-router/dist/vue-router.js"></script>
	<!-- router vue.js -->

	<?php echo $__env->yieldContent('scripts'); ?>

	<!-- app vue.js -->
	<script src="<?php echo e(url('/')); ?>/vue.js/app.js"></script>
	<!-- app vue.js -->


	<!-- bootstrap scripts -->
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
	<!-- bootstrap scripts -->

</body>

</html><?php /**PATH E:\chetan\xampp\htdocs\vue-js-laravel\assignment-app\resources\views/layouts/master-layout.blade.php ENDPATH**/ ?>